package com.DAO.tienda;
import java.sql.*;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;

public class Conexion {
		
	//Parametros de conexion
	//private static final String CONTROLADOR = "com.mysql.jdbc.Driver";
	static String bd = "basedatos";
	static String login = "root";
	//static String password = "admin";
	static String password = "jormungander";
	static String url = "jdbc:mysql://localhost/basedatos";
	Connection connection = null;
	/** Constructor de DbConnection */
	public Conexion() { 
		try{
			//obtenemos el driver de para mysql
			//Class.forName("com.mysql.cj.jdbc.Driver");
			Class.forName("com.mysql.cj.jdbc.Driver");


			//obtenemos la conexión
			connection = DriverManager.getConnection(url,login,password);
			if (connection!=null){
				System.out.println("Conexión a base de datos "+bd+" OK\n");
			}
		}catch(SQLException e){
			System.out.println(e);
		}catch(ClassNotFoundException e){
			System.out.println(e);
		}catch(Exception e){
			System.out.println(e);
		}
	 }
	/**Permite retornar la conexión*/
	public Connection getConnection(){
		return connection;
	}
	public void desconectar(){
		connection = null;
	}
}
